package com.prism.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.TransitionManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

const val MP = -1
const val WC = -2

class Media : NotificationListenerService()

class App(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class Home : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var drawer: FrameLayout
    private lateinit var grid: GridView
    private lateinit var island: LinearLayout
    private lateinit var ctl: LinearLayout
    private lateinit var song: TextView
    private lateinit var play: TextView
    private var apps = listOf<App>()
    private var shown = listOf<App>()
    private var mc: MediaController? = null
    private var big = false
    private var denied = false
    private var x0 = 0f
    private var y0 = 0f
    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable { override fun run() { media(); h.postDelayed(this, 1500) } }
    private val adp = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, g: ViewGroup?): View = cell(shown[i])
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun gi(k: String, d: Int) = p.getInt(k, d)
    private fun rad() = when (gi("shape", 1)) { 0 -> 60; 1 -> 18; else -> 6 }
    private fun glass(r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(when (gi("tint", 0)) { 0 -> Color.argb(110, 16, 20, 32); 1 -> Color.argb(70, 255, 255, 255); else -> Color.argb(210, 0, 0, 0) })
        setStroke(dp(1), Color.argb(60, 255, 255, 255))
    }
    private fun pins() = (p.getString("pins", "") ?: "").split("|").filter { it.isNotEmpty() }

    // ---- icon packs (Nova / ADW appfilter.xml) ----
    private fun loadPack(): Map<String, String> {
        val pk = p.getString("pack", "") ?: ""
        val m = HashMap<String, String>()
        if (pk.isEmpty()) return m
        try {
            val r = packageManager.getResourcesForApplication(pk)
            val id = r.getIdentifier("appfilter", "xml", pk)
            val x: XmlPullParser = if (id != 0) r.getXml(id) else XmlPullParserFactory.newInstance().newPullParser().also { it.setInput(r.assets.open("appfilter.xml"), null) }
            var ev = x.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && x.name == "item") {
                    val c = x.getAttributeValue(null, "component"); val d = x.getAttributeValue(null, "drawable")
                    if (c != null && d != null) m[c] = d
                }
                ev = x.next()
            }
        } catch (ex: Exception) { }
        return m
    }
    private fun iconFor(ri: ResolveInfo, pack: Map<String, String>): Drawable {
        val a = ri.activityInfo
        val d = pack["ComponentInfo{" + a.packageName + "/" + a.name + "}"]
        if (d != null) {
            try {
                val pk = p.getString("pack", "") ?: ""
                val r = packageManager.getResourcesForApplication(pk)
                val id = r.getIdentifier(d, "drawable", pk)
                if (id != 0) return r.getDrawable(id, null)
            } catch (ex: Exception) { }
        }
        return ri.loadIcon(packageManager)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("p", 0)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val pack = loadPack(); val pm = packageManager
        apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, iconFor(it, pack)) }
            .sortedBy { it.label.lowercase() }
        shown = apps
        root = FrameLayout(this)
        root.setOnApplyWindowInsetsListener { v, i -> v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i }
        root.addView(buildHome(), FrameLayout.LayoutParams(MP, MP))
        root.addView(buildDrawer(), FrameLayout.LayoutParams(MP, MP))
        setContentView(root)
    }

    // ---- views ----
    private fun cell(a: App, label: Boolean = true): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8))
        val s = dp(gi("size", 56))
        val t = FrameLayout(context).apply { background = glass(rad()) }
        t.addView(ImageView(context).apply { setImageDrawable(a.icon.constantState?.newDrawable() ?: a.icon); setPadding(s / 6, s / 6, s / 6, s / 6) }, FrameLayout.LayoutParams(s, s))
        addView(t, LinearLayout.LayoutParams(s, s))
        if (label) addView(TextView(context).apply { text = a.label; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, Color.BLACK) }, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(4) })
        setOnClickListener { launch(a) }
        setOnLongClickListener { menu(a); true }
    }
    private fun rows(l: List<App>, c: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        l.chunked(c).forEach { r ->
            addView(LinearLayout(context).apply {
                r.forEach { a -> addView(cell(a), LinearLayout.LayoutParams(0, WC, 1f)) }
                repeat(c - r.size) { addView(View(context), LinearLayout.LayoutParams(0, 1, 1f)) }
            })
        }
    }
    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(20), dp(6), dp(20), dp(6))
        setOnClickListener { f(); h.postDelayed({ media() }, 350) }
    }

    private fun buildHome(): View {
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(14)) }
        // dynamic island (media pill)
        song = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; text = "Prism" }
        play = btn("▶") { mc?.let { c -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play() } }
        ctl = LinearLayout(this).apply {
            gravity = Gravity.CENTER; visibility = View.GONE
            addView(btn("⏮") { mc?.transportControls?.skipToPrevious() }); addView(play); addView(btn("⏭") { mc?.transportControls?.skipToNext() })
        }
        island = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.BLACK) }
            addView(song, LinearLayout.LayoutParams(MP, WC)); addView(ctl)
            setOnClickListener {
                if (denied) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) else {
                    TransitionManager.beginDelayedTransition(home)
                    big = !big; ctl.visibility = if (big) View.VISIBLE else View.GONE
                    layoutParams = (layoutParams as LinearLayout.LayoutParams).apply { width = if (big) MP else dp(190) }
                }
            }
        }
        home.addView(island, LinearLayout.LayoutParams(dp(190), WC).apply { gravity = Gravity.CENTER_HORIZONTAL })
        // clock + date
        val font = arrayOf("sans-serif-thin", "sans-serif-black", "serif", "sans-serif-condensed")[gi("clock", 0)]
        home.addView(TextClock(this).apply { format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 76f; setTextColor(Color.WHITE); typeface = Typeface.create(font, Typeface.NORMAL); gravity = Gravity.CENTER; setShadowLayer(14f, 0f, 2f, Color.argb(100, 0, 0, 0)) }, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(24) })
        home.addView(TextClock(this).apply { format12Hour = "EEEE, MMM d"; format24Hour = "EEEE, MMM d"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(MP, WC))
        // pinned apps
        val pinned = pins().mapNotNull { k -> apps.find { it.pkg == k } }
        home.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(if (pinned.isEmpty()) TextView(context).apply { text = "Swipe up for all apps.\nLong-press an app to pin it here.\nLong-press the home screen for settings."; setTextColor(Color.argb(170, 255, 255, 255)); gravity = Gravity.CENTER; setPadding(0, dp(60), 0, 0) } else rows(pinned, gi("cols", 4)))
        }, LinearLayout.LayoutParams(MP, 0, 1f).apply { topMargin = dp(18) })
        // glass dock
        val dock = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_VIEW, Uri.parse("sms:")), Intent(MediaStore.ACTION_IMAGE_CAPTURE), Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")))
            .mapNotNull { packageManager.resolveActivity(it, 0)?.activityInfo?.packageName }.distinct().mapNotNull { k -> apps.find { it.pkg == k } }
        home.addView(LinearLayout(this).apply {
            background = glass(30); gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
            dock.forEach { addView(cell(it, false), LinearLayout.LayoutParams(0, WC, 1f)) }
            addView(TextView(context).apply { text = "☰"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setOnClickListener { openDrawer() } }, LinearLayout.LayoutParams(0, WC, 1f))
        }, LinearLayout.LayoutParams(MP, WC))
        home.setOnLongClickListener { settings(); true }
        return home
    }

    private fun buildDrawer(): View {
        grid = GridView(this).apply {
            numColumns = gi("cols", 4); adapter = adp; selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false; clipToPadding = false; setPadding(0, dp(8), 0, dp(80))
        }
        val q = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(Color.argb(150, 255, 255, 255)); setTextColor(Color.WHITE)
            background = glass(24); setPadding(dp(18), dp(12), dp(18), dp(12)); isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { shown = apps.filter { it.label.contains(s.toString(), true) }; adp.notifyDataSetChanged() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val idx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            ('A'..'Z').forEach { c -> addView(TextView(context).apply { text = c.toString(); textSize = 10f; setTextColor(Color.argb(200, 255, 255, 255)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(22), 0, 1f)) }
            setOnTouchListener { v, e ->
                val ch = 'A' + ((e.y / v.height) * 26).toInt().coerceIn(0, 25)
                val pos = shown.indexOfFirst { (it.label.uppercase().firstOrNull() ?: '0') >= ch }
                if (pos >= 0) grid.setSelection(pos)
                true
            }
        }
        val body = LinearLayout(this).apply { addView(grid, LinearLayout.LayoutParams(0, MP, 1f)); addView(idx, LinearLayout.LayoutParams(dp(22), MP)) }
        drawer = FrameLayout(this).apply {
            visibility = View.GONE; setBackgroundColor(Color.argb(150, 0, 0, 0)); setPadding(dp(16), dp(56), dp(12), 0)
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; addView(q, LinearLayout.LayoutParams(MP, WC)); addView(body, LinearLayout.LayoutParams(MP, 0, 1f)) }, FrameLayout.LayoutParams(MP, MP))
        }
        return drawer
    }

    // ---- actions ----
    private fun openDrawer() { drawer.alpha = 0f; drawer.translationY = dp(60).toFloat(); drawer.visibility = View.VISIBLE; drawer.animate().alpha(1f).translationY(0f).setDuration(220).start(); blur(true) }
    private fun closeDrawer() { if (drawer.visibility != View.VISIBLE) return; drawer.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(180).withEndAction { drawer.visibility = View.GONE }.start(); blur(false) }
    private fun blur(on: Boolean) { if (Build.VERSION.SDK_INT >= 31) window.setBackgroundBlurRadius(if (on) 90 else 0) }
    private fun launch(a: App) {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); closeDrawer() }
        catch (ex: Exception) { Toast.makeText(this, "Cannot open " + a.label, Toast.LENGTH_SHORT).show() }
    }
    private fun menu(a: App) {
        val l = pins(); val on = a.pkg in l
        AlertDialog.Builder(this).setTitle(a.label).setItems(arrayOf(if (on) "Remove from home" else "Pin to home", "App info", "Uninstall")) { _, w ->
            when (w) {
                0 -> { p.edit().putString("pins", (if (on) l - a.pkg else l + a.pkg).joinToString("|")).apply(); recreate() }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
                else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)))
            }
        }.show()
    }
    private fun pick(t: String, o: Array<String>, k: String, v: IntArray = IntArray(o.size) { it }) {
        AlertDialog.Builder(this).setTitle(t).setItems(o) { _, w -> p.edit().putInt(k, v[w]).apply(); recreate() }.show()
    }
    private fun packs() {
        val pm = packageManager
        val l = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME").flatMap { pm.queryIntentActivities(Intent(it), 0) }.map { it.activityInfo.packageName }.distinct()
        if (l.isEmpty()) Toast.makeText(this, "No Nova/ADW icon packs installed", Toast.LENGTH_LONG).show()
        val names = listOf("Default (no pack)") + l.map { pm.getApplicationInfo(it, 0).loadLabel(pm).toString() }
        AlertDialog.Builder(this).setTitle("Icon pack").setItems(names.toTypedArray()) { _, w -> p.edit().putString("pack", if (w == 0) "" else l[w - 1]).apply(); recreate() }.show()
    }
    private fun settings() {
        val o = arrayOf("Glass tint", "Icon shape", "Icon size", "Columns", "Clock style", "Icon pack", "Media access (island)", "Default home app")
        AlertDialog.Builder(this).setTitle("Prism settings").setItems(o) { _, w ->
            when (w) {
                0 -> pick("Glass tint", arrayOf("Smoke", "Frost", "Black"), "tint")
                1 -> pick("Icon shape", arrayOf("Circle", "Squircle", "Square"), "shape")
                2 -> pick("Icon size", arrayOf("Small", "Medium", "Large", "XL"), "size", intArrayOf(48, 56, 64, 72))
                3 -> pick("Columns", arrayOf("4", "5", "6"), "cols", intArrayOf(4, 5, 6))
                4 -> pick("Clock style", arrayOf("Thin", "Black", "Serif", "Condensed"), "clock")
                5 -> packs()
                6 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                else -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        }.show()
    }
    private fun media() {
        try {
            val sm = getSystemService(MediaSessionManager::class.java)
            mc = sm.getActiveSessions(ComponentName(this, Media::class.java)).firstOrNull()
            denied = false
            val m = mc?.metadata
            val t = m?.getString(MediaMetadata.METADATA_KEY_TITLE); val ar = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            song.text = if (t == null) "Nothing playing" else if (ar == null) t else "$t · $ar"
            play.text = if (mc?.playbackState?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
        } catch (ex: SecurityException) { denied = true; song.text = "Tap to allow media access" }
    }

    // ---- lifecycle / gestures ----
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) { x0 = e.rawX; y0 = e.rawY }
        if (e.action == MotionEvent.ACTION_UP && drawer.visibility != View.VISIBLE && y0 - e.rawY > dp(110) && Math.abs(e.rawX - x0) < dp(90)) openDrawer()
        return super.dispatchTouchEvent(e)
    }
    override fun onResume() { super.onResume(); h.post(poll) }
    override fun onPause() { super.onPause(); h.removeCallbacks(poll) }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); closeDrawer() }
    override fun onBackPressed() { closeDrawer() }
}
